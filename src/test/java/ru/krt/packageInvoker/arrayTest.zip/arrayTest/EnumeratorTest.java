package ru.krt.packageInvoker.arrayTest;

import ru.krt.packageInvoker.PackageEnumerator;

import java.util.ArrayList;

public abstract class EnumeratorTest extends PackageEnumerator {
    public EnumeratorTest() {
        packageObjects = new ArrayList<>();
    }
}
