package ru.krt.packageInvoker.arrayTest;

public class ObjectTest extends EnumeratorTest{
    public ObjectTest() {
        String testName = "testName";
        objectId = new String[]{testName};
        addObject(testName);
    }

    @Override
    public Object mainMethod() {
        return "testResult";
    }
}
